const CalendarioCliente = ({ registrations, eventos }) => {
  // Filtra eventos onde o cliente está inscrito ou na fila
  const meusAgendamentos = eventos.filter(ev => 
    registrations.some(r => r.eventoId === ev.id)
  );

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-slate-50 mb-6">Minha Agenda</h2>
      
      {meusAgendamentos.length === 0 ? (
        <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-dashed border-slate-800">
          <p className="text-slate-500 text-lg">Você ainda não tem compromissos agendados.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {meusAgendamentos.map(ev => {
            const statusObj = registrations.find(r => r.eventoId === ev.id);
            return (
              <div key={ev.id} className="group relative bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-blue-500/50 transition-colors">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex gap-4 items-start">
                    <div className="bg-blue-600/10 text-blue-500 p-3 rounded-lg text-center min-w-[60px]">
                      <span className="block text-xs uppercase font-bold">Dia</span>
                      <span className="text-xl font-black">{ev.data.split('/')[0]}</span>
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-100 text-lg">{ev.titulo}</h3>
                      <p className="text-slate-500">{ev.estabelecimento} • {ev.horario}</p>
                    </div>
                  </div>
                  
                  <div className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-widest border ${
                    statusObj.status === 'inscrito' ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                  }`}>
                    {statusObj.status}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default CalendarioCliente;