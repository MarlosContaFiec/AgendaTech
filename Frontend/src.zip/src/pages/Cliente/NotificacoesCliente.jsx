const NotificacoesCliente = ({ notificacoes, onMarcarLida, onMarcarTodasLidas, onAceitarFila, onRecusarFila }) => {
  
  const temNotificacoes = notificacoes && notificacoes.length > 0;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-50">Notificações</h2>
          <p className="text-slate-400 text-sm">Acompanhe o status dos seus agendamentos</p>
        </div>
        
        {temNotificacoes && (
          <button 
            onClick={onMarcarTodasLidas}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors uppercase tracking-wider"
          >
            Marcar todas como lidas
          </button>
        )}
      </div>

      {!temNotificacoes ? (
        <div className="flex flex-col items-center justify-center py-20 bg-slate-900/30 rounded-3xl border border-dashed border-slate-800">
          <div className="bg-slate-800/50 p-4 rounded-full mb-4">
            <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
            </svg>
          </div>
          <p className="text-slate-500 font-medium">Você não tem novas notificações.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notificacoes.map((notif) => (
            <div 
              key={notif.id} 
              className={`relative p-5 rounded-2xl border transition-all ${
                notif.lida 
                ? 'bg-slate-900/40 border-slate-800/50 opacity-75' 
                : 'bg-slate-900 border-blue-500/30 shadow-lg shadow-blue-900/5'
              }`}
            >
              <div className="flex justify-between items-start gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    {!notif.lida && <span className="w-2 h-2 bg-blue-500 rounded-full"></span>}
                    <h3 className={`font-bold ${notif.lida ? 'text-slate-300' : 'text-slate-50'}`}>
                      {notif.titulo}
                    </h3>
                  </div>
                  <p className="text-slate-400 text-sm leading-relaxed mb-3">
                    {notif.mensagem}
                  </p>
                  <span className="text-[10px] text-slate-600 font-medium uppercase tracking-tighter">
                    {notif.data}
                  </span>
                </div>

                {!notif.lida && (
                  <button 
                    onClick={() => onMarcarLida(notif.id)}
                    className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 transition-colors"
                    title="Marcar como lida"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  </button>
                )}
              </div>

              {/* Se for uma notificação de convite da fila de espera */}
              {notif.tipo === 'convite_fila' && !notif.respondida && (
                <div className="mt-4 flex gap-2 border-t border-slate-800 pt-4">
                  <button 
                    onClick={() => onAceitarFila(notif)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-bold py-2 rounded-lg transition-colors"
                  >
                    Confirmar Presença
                  </button>
                  <button 
                    onClick={() => onRecusarFila(notif)}
                    className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-bold py-2 rounded-lg transition-colors"
                  >
                    Recusar
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificacoesCliente;