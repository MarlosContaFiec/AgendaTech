const Servicos = ({ eventos = [], registrations = [], onInscrever, onCancelar, onEntrarFila }) => {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white italic tracking-tight">Serviços Disponíveis</h2>
        <p className="text-slate-400">Escolha um serviço e faça sua reserva.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {eventos.map(ev => {
          const reg = registrations.find(r => r.eventoId === ev.id);
          const isInscrito = reg?.status === 'inscrito';
          const isPendente = reg?.status === 'pendente';
          const isFila = reg?.status === 'fila';

          return (
            <div key={ev.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-blue-500/50 transition-all group">
              <div className="h-32 bg-gradient-to-br from-slate-800 to-slate-900 p-4">
                <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-1 rounded uppercase">
                  {ev.tipo || 'Geral'}
                </span>
              </div>
              
              <div className="p-5">
                <h3 className="text-lg font-bold text-white mb-1 leading-tight">{ev.titulo}</h3>
                <p className="text-slate-500 text-sm mb-4">{ev.estabelecimento}</p>
                
                <div className="flex flex-col gap-2 text-xs text-slate-400 mb-6">
                  <div className="flex items-center gap-2"><span>📅</span> {ev.data}</div>
                  <div className="flex items-center gap-2"><span>⏰</span> {ev.horario}</div>
                </div>

                <div className="flex flex-col gap-2">
                  {isInscrito ? (
                    <button 
                      onClick={() => onCancelar(ev.id)}
                      className="w-full py-2.5 bg-red-500/10 text-red-500 rounded-xl font-bold text-sm border border-red-500/20 hover:bg-red-500/20 transition-colors"
                    >
                      Cancelar Inscrição
                    </button>
                  ) : isPendente ? (
                    <button disabled className="w-full py-2.5 bg-slate-800 text-slate-500 rounded-xl font-bold text-sm border border-slate-700">
                      Aguardando Aprovação
                    </button>
                  ) : isFila ? (
                    <button className="w-full py-2.5 bg-amber-500/10 text-amber-500 rounded-xl font-bold text-sm cursor-default">
                      Em Fila de Espera
                    </button>
                  ) : ev.vagasDisponiveis > 0 ? (
                    <button 
                      onClick={() => onInscrever(ev)}
                      className="w-full py-2.5 bg-blue-600 text-white rounded-xl font-bold text-sm hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/20"
                    >
                      Reservar Agora
                    </button>
                  ) : (
                    <button 
                      onClick={() => onEntrarFila(ev)}
                      className="w-full py-2.5 bg-slate-800 text-slate-300 rounded-xl font-bold text-sm hover:bg-slate-700 transition-all"
                    >
                      Entrar na Fila
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Servicos;