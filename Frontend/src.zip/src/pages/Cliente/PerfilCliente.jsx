const PerfilCliente = ({ perfil, setPerfil, onSave }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setPerfil(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-slate-900 rounded-2xl border border-slate-800 mt-6">
      <h2 className="text-xl font-bold text-slate-50 mb-6 border-b border-slate-800 pb-4">
        Meu Perfil
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-slate-400">Nome Completo</label>
          <input 
            name="nome"
            value={perfil.nome}
            onChange={handleChange}
            className="bg-slate-950 border border-slate-800 text-slate-200 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="Digite seu nome"
          />
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-slate-400">WhatsApp / Telefone</label>
          <input 
            name="telefone"
            value={perfil.telefone}
            onChange={handleChange}
            className="bg-slate-950 border border-slate-800 text-slate-200 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="(00) 00000-0000"
          />
        </div>

        <div className="flex flex-col gap-2 md:col-span-2">
          <label className="text-sm font-medium text-slate-400">CPF</label>
          <input 
            name="cpf"
            value={perfil.cpf}
            onChange={handleChange}
            className="bg-slate-950 border border-slate-800 text-slate-200 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
      </div>

      <button 
        onClick={onSave}
        className="w-full mt-8 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-blue-900/20"
      >
        Salvar Alterações
      </button>
    </div>
  );
};

export default PerfilCliente;