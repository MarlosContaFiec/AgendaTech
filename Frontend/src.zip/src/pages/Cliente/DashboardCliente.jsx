import { useMemo } from 'react';

const DashboardCliente = ({ perfil, registrations, eventos }) => {
  // Lógica de cálculo de estatísticas extraída do seu código
  const stats = useMemo(() => {
    const inscritos = registrations.filter(r => r.status === "inscrito").length;
    const fila = registrations.filter(r => r.status === "fila").length;
    const pendentes = registrations.filter(r => r.status === "pendente").length;
    return { inscritos, fila, pendentes };
  }, [registrations]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-50">Olá, {perfil.nome || 'Cliente'}!</h1>
        <p className="text-slate-400">Aqui está o resumo das suas atividades.</p>
      </div>

      {/* Grid de Stats com Tailwind */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Inscrições Ativas</span>
          <div className="text-3xl font-bold text-blue-500 mt-2">{stats.inscritos}</div>
        </div>
        
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Na Fila de Espera</span>
          <div className="text-3xl font-bold text-amber-500 mt-2">{stats.fila}</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Pendentes</span>
          <div className="text-3xl font-bold text-purple-500 mt-2">{stats.pendentes}</div>
        </div>
      </div>

      {/* Lista rápida de próximos eventos */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold text-slate-200 mb-4">Seus Próximos Eventos</h2>
        <div className="space-y-3">
          {eventos.slice(0, 3).map(ev => (
            <div key={ev.id} className="flex justify-between items-center bg-slate-900/50 p-4 rounded-lg border border-slate-800">
              <div>
                <p className="font-medium text-slate-100">{ev.titulo}</p>
                <p className="text-sm text-slate-500">{ev.data} • {ev.horario}</p>
              </div>
              <span className="text-xs bg-blue-500/10 text-blue-400 px-2 py-1 rounded-full border border-blue-500/20">
                Confirmado
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardCliente;