const Solicitacoes = ({ reservas, onAprovar, onRejeitar }) => {
  const pendentes = reservas.filter(r => r.status === 'pendente');

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-white mb-6">Solicitações Pendentes</h2>

      {pendentes.length === 0 ? (
        <div className="text-center py-16 bg-slate-900/50 rounded-2xl border-2 border-dashed border-slate-800">
          <p className="text-slate-500">Nenhuma solicitação aguardando aprovação.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {pendentes.map(res => (
            <div key={res.id} className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex flex-col md:flex-row justify-between items-center gap-4">
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center font-bold text-blue-400">
                  {res.clienteNome?.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-slate-100">{res.clienteNome}</h4>
                  <p className="text-sm text-slate-400">Solicitou reserva para: <span className="text-slate-200">{res.eventoTitulo}</span></p>
                </div>
              </div>

              <div className="flex gap-2 w-full md:w-auto">
                <button 
                  onClick={() => onAprovar(res.id)}
                  className="flex-1 md:flex-none px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-bold text-sm transition-colors"
                >
                  Aprovar
                </button>
                <button 
                  onClick={() => onRejeitar(res.id)}
                  className="flex-1 md:flex-none px-6 py-2 bg-red-600/10 hover:bg-red-600/20 text-red-500 rounded-lg font-bold text-sm transition-colors"
                >
                  Recusar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Solicitacoes;