import { useMemo } from 'react';

const DashboardEmpresa = ({ eventos, reservas }) => {
  const stats = useMemo(() => {
    const totalEventos = eventos.length;
    const totalReservas = reservas.length;
    const confirmadas = reservas.filter(r => r.status === 'confirmado').length;
    
    return { totalEventos, totalReservas, confirmadas };
  }, [eventos, reservas]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Painel Administrativo</h1>
        <span className="bg-blue-500/10 text-blue-400 px-3 py-1 rounded-full text-xs font-medium border border-blue-500/20">
          Operação em tempo real
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Eventos Ativos</p>
          <p className="text-3xl font-black text-white mt-2">{stats.totalEventos}</p>
        </div>
        
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Total de Reservas</p>
          <p className="text-3xl font-black text-green-400 mt-2">{stats.totalReservas}</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <p className="text-slate-400 text-sm font-medium uppercase tracking-wider">Taxa de Ocupação</p>
          <p className="text-3xl font-black text-purple-400 mt-2">
            {stats.totalReservas > 0 ? ((stats.confirmadas / stats.totalReservas) * 100).toFixed(0) : 0}%
          </p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex justify-between items-center">
          <h3 className="font-bold text-slate-200">Eventos Recentes</h3>
          <button className="text-blue-400 text-sm hover:underline">Ver todos</button>
        </div>
        <div className="divide-y divide-slate-800">
          {eventos.slice(0, 5).map(ev => (
            <div key={ev.id} className="p-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors">
              <div>
                <p className="font-semibold text-slate-100">{ev.titulo}</p>
                <p className="text-xs text-slate-500">{ev.data} • {ev.tipo}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-slate-300">{ev.vagasDisponiveis} vagas restando</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardEmpresa;