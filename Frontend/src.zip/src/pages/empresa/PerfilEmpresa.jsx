const PerfilEmpresa = ({ empresa, setEmpresa, onSave }) => {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="h-32 bg-gradient-to-r from-blue-600 to-indigo-700"></div>
        <div className="p-8 -mt-16">
          <div className="flex flex-col md:flex-row gap-6 items-end mb-8">
            <div className="w-32 h-32 bg-slate-800 border-4 border-slate-900 rounded-2xl flex items-center justify-center text-4xl shadow-2xl">
              🏢
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white">{empresa.nomeFantasia || 'Nome da Empresa'}</h2>
              <p className="text-slate-400 text-sm">{empresa.cnpj || 'CNPJ não informado'}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-400">Nome Fantasia</label>
              <input 
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:border-blue-500 outline-none transition-colors"
                value={empresa.nomeFantasia}
                onChange={(e) => setEmpresa({...empresa, nomeFantasia: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-400">E-mail Comercial</label>
              <input 
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:border-blue-500 outline-none transition-colors"
                value={empresa.email}
                onChange={(e) => setEmpresa({...empresa, email: e.target.value})}
              />
            </div>
          </div>

          <button 
            onClick={onSave}
            className="mt-8 w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all"
          >
            Salvar Perfil da Empresa
          </button>
        </div>
      </div>
    </div>
  );
};

export default PerfilEmpresa;