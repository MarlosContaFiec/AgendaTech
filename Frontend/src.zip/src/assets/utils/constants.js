export const APP_CONFIG = {
  CLIENT_ID: "c_local",
  POLITICA_CANCELAMENTO: {
    horasAntecedencia: 24,
    texto: "Cancelamentos com menos de 24h podem gerar taxas."
  },
  ESTADOS: ["SP", "RJ", "MG", "PR", "SC"],
  CIDADES_POR_ESTADO: {
    SP: ["Indaiatuba", "Campinas", "São Paulo"],
    RJ: ["Rio de Janeiro", "Niterói"],
    // Adicione o resto aqui...
  }
};