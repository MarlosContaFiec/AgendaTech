const STORE_KEY = "trustbook_shared_v1";

export const storage = {
  // Procura todos os dados (eventos, reservas, utilizadores)
  getShared: () => {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      return raw ? JSON.parse(raw) : { eventos: [], registrations: [], notificacoes: [] };
    } catch (error) {
      console.error("Erro ao ler storage", error);
      return { eventos: [], registrations: [], notificacoes: [] };
    }
  },

  // Grava os dados atualizados
  setShared: (data) => {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Erro ao gravar storage", error);
    }
  },

  // Atalho para atualizar apenas uma parte (ex: apenas eventos)
  updateKey: (key, value) => {
    const data = storage.getShared();
    data[key] = value;
    storage.setShared(data);
  }
};