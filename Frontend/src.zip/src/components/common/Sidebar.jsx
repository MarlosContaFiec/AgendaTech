const Sidebar = ({ opcoes, abaAtiva, setAba, tituloLogo = "TRUSTBOOK" }) => {
  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col h-screen sticky top-0">
      <div className="p-8">
        <h1 className="text-2xl font-black text-blue-500 tracking-tighter italic">{tituloLogo}</h1>
      </div>

      <nav className="flex-1 px-4 space-y-2">
        {opcoes.map((item) => (
          <button
            key={item.id}
            onClick={() => setAba(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
              abaAtiva === item.id 
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' 
              : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button className="w-full flex items-center gap-3 px-4 py-3 text-slate-500 hover:text-red-400 text-sm font-medium transition-colors">
          <span>🚪</span> Sair
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;