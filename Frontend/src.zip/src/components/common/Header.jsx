const Header = ({ titulo, usuario }) => {
  return (
    <header className="h-20 border-b border-slate-800 bg-slate-950/50 backdrop-blur-md flex items-center justify-between px-8 sticky top-0 z-10">
      <h2 className="text-xl font-bold text-white">{titulo}</h2>
      
      <div className="flex items-center gap-4">
        <div className="text-right hidden md:block">
          <p className="text-sm font-bold text-slate-200">{usuario?.nome || 'Utilizador'}</p>
          <p className="text-[10px] text-blue-500 font-bold uppercase tracking-widest">Sessão Ativa</p>
        </div>
        <div className="w-10 h-10 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-white font-bold ring-2 ring-blue-600/20">
          {usuario?.nome?.charAt(0) || 'U'}
        </div>
      </div>
    </header>
  );
};

export default Header;