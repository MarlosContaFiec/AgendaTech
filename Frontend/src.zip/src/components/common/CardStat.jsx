const CardStat = ({ label, valor, cor = "blue" }) => {
  const cores = {
    blue: "text-blue-500 bg-blue-500/10 border-blue-500/20",
    green: "text-green-500 bg-green-500/10 border-green-500/20",
    amber: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    purple: "text-purple-500 bg-purple-500/10 border-purple-500/20",
  };

  return (
    <div className={`p-6 rounded-2xl border bg-slate-900/50 ${cores[cor] || cores.blue}`}>
      <p className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-2">{label}</p>
      <p className="text-3xl font-black text-white">{valor}</p>
    </div>
  );
};

export default CardStat;