import { useState, useEffect, useMemo } from 'react';

// 1. Ajuste nos Utils (Dentro de assets)
import { storage } from './assets/utils/storage';
import { formatters } from './assets/utils/formatters';

// 2. Componentes Common
import Sidebar from './components/common/Sidebar';
import Header from './components/common/Header';

// 3. Páginas Cliente (Corrigido para ./pages)
import DashboardCliente from './pages/Cliente/DashboardCliente';
import Servicos from './pages/Cliente/Servicos';
import CalendarioCliente from './pages/Cliente/CalendarioCliente';
import NotificacoesCliente from './pages/Cliente/NotificacoesCliente';
import PerfilCliente from './pages/Cliente/PerfilCliente';

// 4. Páginas Empresa
import DashboardEmpresa from './pages/Empresa/DashboardEmpresa';
import Solicitacoes from './pages/Empresa/Solicitacoes';
import PerfilEmpresa from './pages/Empresa/PerfilEmpresa';

function App() {
  const [view, setView] = useState('cliente');
  const [aba, setAba] = useState('dashboard');
  
  // Garante que o estado inicial tenha a estrutura correta para evitar erros de undefined
  const [dados, setDados] = useState(() => {
    const defaultData = { eventos: [], registrations: [], notificacoes: [] };
    return storage.getShared() || defaultData;
  });

  const [perfil, setPerfil] = useState({ 
    nome: 'Usuário Teste', 
    telefone: '', 
    cpf: '' 
  });

  useEffect(() => {
    storage.setShared(dados);
  }, [dados]);

  const menuCliente = [
    { id: 'dashboard', label: 'Início', icon: '🏠' },
    { id: 'servicos', label: 'Serviços', icon: '📋' },
    { id: 'calendario', label: 'Agenda', icon: '📅' },
    { id: 'notificacoes', label: 'Avisos', icon: '🔔' },
    { id: 'perfil', label: 'Perfil', icon: '👤' },
  ];

  const menuEmpresa = [
    { id: 'dashboard', label: 'Painel', icon: '📊' },
    { id: 'solicitacoes', label: 'Reservas', icon: '📩' },
    { id: 'perfil', label: 'Minha Empresa', icon: '🏢' },
  ];

  const handleInscrever = (evento) => {
    const novaReserva = {
      id: Date.now(),
      eventoId: evento.id,
      eventoTitulo: evento.titulo,
      clienteNome: perfil.nome,
      status: 'pendente',
      data: new Date().toLocaleDateString()
    };
    setDados(prev => ({
      ...prev,
      registrations: [...(prev.registrations || []), novaReserva]
    }));
  };

  const handleCancelar = (eventoId) => {
    setDados(prev => ({
      ...prev,
      registrations: (prev.registrations || []).filter(r => r.eventoId !== eventoId)
    }));
  };

  const handleAprovar = (reservaId) => {
    setDados(prev => ({
      ...prev,
      registrations: (prev.registrations || []).map(r => 
        r.id === reservaId ? { ...r, status: 'inscrito' } : r
      )
    }));
  };

  const renderContent = () => {
    if (view === 'cliente') {
      switch (aba) {
        case 'dashboard': return <DashboardCliente perfil={perfil} registrations={dados.registrations} eventos={dados.eventos} />;
        case 'servicos': return <Servicos eventos={dados.eventos} registrations={dados.registrations} onInscrever={handleInscrever} onCancelar={handleCancelar} />;
        case 'calendario': return <CalendarioCliente registrations={dados.registrations} eventos={dados.eventos} />;
        case 'notificacoes': return <NotificacoesCliente notificacoes={dados.notificacoes} />;
        case 'perfil': return <PerfilCliente perfil={perfil} setPerfil={setPerfil} />;
        default: return <DashboardCliente />;
      }
    } else {
      switch (aba) {
        case 'dashboard': return <DashboardEmpresa eventos={dados.eventos} reservas={dados.registrations} />;
        case 'solicitacoes': return <Solicitacoes reservas={dados.registrations} onAprovar={handleAprovar} />;
        case 'perfil': return <PerfilEmpresa empresa={dados.empresa || {}} />;
        default: return <DashboardEmpresa />;
      }
    }
  };

  return (
    <div className="flex min-h-screen bg-[#080a0f] text-slate-200 font-sans">
      <button 
        onClick={() => { setView(view === 'cliente' ? 'empresa' : 'cliente'); setAba('dashboard'); }}
        className="fixed bottom-6 right-6 z-50 bg-white text-black px-6 py-3 rounded-full font-bold shadow-2xl hover:scale-105 transition-transform active:scale-95"
      >
        Mudar para {view === 'cliente' ? 'Empresa' : 'Cliente'}
      </button>

      <Sidebar opcoes={view === 'cliente' ? menuCliente : menuEmpresa} abaAtiva={aba} setAba={setAba} />

      <main className="flex-1 flex flex-col h-screen">
        <Header titulo={aba.toUpperCase()} usuario={perfil} />
        <div className="flex-1 overflow-y-auto bg-slate-950/30">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}

export default App;